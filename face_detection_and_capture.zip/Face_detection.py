import cv2,time,random

video = cv2.VideoCapture(0)

a = 1

while True:
    a = a + 1
    status, frame = video.read()

    #print(status)
    #print(frame)

    #convert gray
    
    gray_img = cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)

    face_cascade = cv2.CascadeClassifier("oc\\data\\haarcascades\\haarcascade_frontalface_default.xml")

    faces = face_cascade.detectMultiScale(gray_img, scaleFactor=1.05, minNeighbors=8)

    name = "capture_images\\suspect_"+str(random.randint(1,201)*5)+".jpg"
    for x,y,w,h in faces:
        frame = cv2.rectangle(frame, (x,y), (x+w, y+h), (0,255,0),2)
        cv2.imwrite(name,frame)

    resized  = cv2.resize(frame,(int(frame.shape[1]) , int(frame.shape[0])))

    #cv2.imshow("photo",gray_img)
    cv2.imshow("photo",resized)

    key = cv2.waitKey(1)
    print(key)
    if key == 27:
        break

    #print(a)

video.release()
cv2.destroyAllWindows()
